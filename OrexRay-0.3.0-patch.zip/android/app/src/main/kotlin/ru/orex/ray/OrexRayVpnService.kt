package ru.orex.ray

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.net.VpnService
import android.os.Build
import android.os.IBinder
import android.os.ParcelFileDescriptor
import android.os.SystemClock
import go.Seq
import libv2ray.CoreCallbackHandler
import libv2ray.CoreController
import libv2ray.Libv2ray
import java.io.File
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit

class OrexRayVpnService : VpnService(), CoreCallbackHandler {
    companion object {
        const val ACTION_START = "ru.orex.ray.action.START"
        const val ACTION_STOP = "ru.orex.ray.action.STOP"
        const val EXTRA_CONFIG = "xray_config"

        private const val NOTIFICATION_CHANNEL_ID = "orexray_vpn"
        private const val NOTIFICATION_ID = 7701
    }

    private val worker = Executors.newSingleThreadScheduledExecutor()
    private lateinit var coreController: CoreController
    private var vpnInterface: ParcelFileDescriptor? = null
    private var statsTask: ScheduledFuture<*>? = null
    private var startedAtElapsedMs = 0L
    private var downloadBytes = 0L
    private var uploadBytes = 0L

    @Volatile
    private var stopping = false

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        Seq.setContext(applicationContext)
        val envDir = File(filesDir, "xray").apply { mkdirs() }
        Libv2ray.initCoreEnv(envDir.absolutePath, "orexray")
        coreController = Libv2ray.newCoreController(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> worker.execute { stopTunnel() }
            ACTION_START -> {
                val config = intent.getStringExtra(EXTRA_CONFIG)
                if (config.isNullOrBlank()) {
                    emitError("Не передан Xray-конфиг")
                    stopSelf()
                    return Service.START_NOT_STICKY
                }

                startInForeground("Подключаем белочку к маршруту…")
                worker.execute { startTunnel(config) }
            }
        }
        return Service.START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = super.onBind(intent)

    override fun onRevoke() {
        worker.execute { stopTunnel() }
        super.onRevoke()
    }

    override fun onDestroy() {
        statsTask?.cancel(true)
        if (!stopping && ::coreController.isInitialized) {
            runCatching { coreController.stopLoop() }
        }
        runCatching { vpnInterface?.close() }
        vpnInterface = null
        worker.shutdownNow()
        super.onDestroy()
    }

    private fun startTunnel(config: String) {
        if (coreController.isRunning) {
            emitConnected()
            return
        }

        try {
            stopping = false
            downloadBytes = 0
            uploadBytes = 0
            startedAtElapsedMs = 0

            OrexRayTunnelEvents.emit(
                OrexRayTunnelEvents.event(
                    status = "connecting",
                    message = "Создаём Android TUN…",
                ),
            )

            vpnInterface = buildVpnInterface()
                ?: error("Android не смог создать TUN-интерфейс")

            OrexRayTunnelEvents.emit(
                OrexRayTunnelEvents.event(
                    status = "connecting",
                    message = "Запускаем Xray Core…",
                ),
            )

            coreController.startLoop(config, vpnInterface!!.fd)
            if (!coreController.isRunning) {
                error("Xray Core завершился сразу после запуска")
            }

            startedAtElapsedMs = SystemClock.elapsedRealtime()
            emitConnected()
            startStatsLoop()
            updateNotification("OrexRay работает")
        } catch (error: Throwable) {
            cleanupAfterFailure()
            emitError(error.message ?: error.javaClass.simpleName)
            stopForegroundCompat()
            stopSelf()
        }
    }

    private fun buildVpnInterface(): ParcelFileDescriptor? {
        val builder = Builder()
            .setSession("OrexRay")
            .setMtu(1500)
            .addAddress("10.77.0.1", 24)
            .addRoute("0.0.0.0", 0)
            .addDnsServer("1.1.1.1")
            .addDnsServer("8.8.8.8")

        // The Xray process lives in this application. Excluding the app keeps
        // Xray's own outbound sockets outside the VPN and prevents a routing loop.
        try {
            builder.addDisallowedApplication(packageName)
        } catch (_: PackageManager.NameNotFoundException) {
            // The current package always exists; keep the VPN usable even if an
            // OEM PackageManager behaves unexpectedly.
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            builder.setMetered(false)
        }

        return builder.establish()
    }

    private fun startStatsLoop() {
        statsTask?.cancel(false)
        statsTask = worker.scheduleAtFixedRate(
            {
                if (!coreController.isRunning || stopping) return@scheduleAtFixedRate
                downloadBytes += coreController.queryStats("proxy", "downlink").coerceAtLeast(0)
                uploadBytes += coreController.queryStats("proxy", "uplink").coerceAtLeast(0)
                emitConnected()
            },
            1,
            1,
            TimeUnit.SECONDS,
        )
    }

    private fun emitConnected() {
        val durationSeconds = if (startedAtElapsedMs == 0L) {
            0L
        } else {
            (SystemClock.elapsedRealtime() - startedAtElapsedMs) / 1000L
        }
        OrexRayTunnelEvents.emit(
            OrexRayTunnelEvents.event(
                status = "connected",
                message = "OrexRay работает",
                downloadBytes = downloadBytes,
                uploadBytes = uploadBytes,
                durationSeconds = durationSeconds,
            ),
        )
    }

    private fun stopTunnel() {
        if (stopping) return
        stopping = true

        OrexRayTunnelEvents.emit(
            OrexRayTunnelEvents.event(
                status = "disconnecting",
                message = "Останавливаем туннель…",
                downloadBytes = downloadBytes,
                uploadBytes = uploadBytes,
                durationSeconds = elapsedSeconds(),
            ),
        )

        statsTask?.cancel(false)
        statsTask = null
        runCatching { if (coreController.isRunning) coreController.stopLoop() }
        runCatching { vpnInterface?.close() }
        vpnInterface = null
        stopForegroundCompat()

        OrexRayTunnelEvents.emit(OrexRayTunnelEvents.event(status = "disconnected"))
        stopSelf()
    }

    private fun cleanupAfterFailure() {
        statsTask?.cancel(false)
        statsTask = null
        runCatching { if (coreController.isRunning) coreController.stopLoop() }
        runCatching { vpnInterface?.close() }
        vpnInterface = null
    }

    private fun elapsedSeconds(): Long = if (startedAtElapsedMs == 0L) {
        0L
    } else {
        (SystemClock.elapsedRealtime() - startedAtElapsedMs) / 1000L
    }

    private fun emitError(message: String) {
        OrexRayTunnelEvents.emit(
            OrexRayTunnelEvents.event(
                status = "error",
                errorMessage = message,
                downloadBytes = downloadBytes,
                uploadBytes = uploadBytes,
                durationSeconds = elapsedSeconds(),
            ),
        )
    }

    private fun startInForeground(text: String) {
        val notification = buildNotification(text)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE,
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun updateNotification(text: String) {
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIFICATION_ID, buildNotification(text))
    }

    private fun buildNotification(text: String): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )

        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, NOTIFICATION_CHANNEL_ID)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }

        return builder
            .setSmallIcon(R.drawable.orexray_icon)
            .setContentTitle("OrexRay")
            .setContentText(text)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setCategory(Notification.CATEGORY_SERVICE)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val channel = NotificationChannel(
            NOTIFICATION_CHANNEL_ID,
            "OrexRay VPN",
            NotificationManager.IMPORTANCE_LOW,
        ).apply {
            description = "Состояние защищённого туннеля OrexRay"
            setShowBadge(false)
        }
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    private fun stopForegroundCompat() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            stopForeground(STOP_FOREGROUND_REMOVE)
        } else {
            @Suppress("DEPRECATION")
            stopForeground(true)
        }
    }

    override fun startup(): Long = 0L

    override fun shutdown(): Long = 0L

    override fun onEmitStatus(code: Long, message: String?): Long {
        // Core lifecycle messages are intentionally not mapped to UI states.
        // OrexRay owns the connection state machine, which avoids a late
        // "Core stopped" callback briefly turning Disconnecting into Connecting.
        return 0L
    }
}
