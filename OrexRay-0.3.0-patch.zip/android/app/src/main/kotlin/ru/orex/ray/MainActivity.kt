package ru.orex.ray

import android.app.Activity
import android.content.Intent
import android.net.VpnService
import android.os.Build
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    companion object {
        private const val METHOD_CHANNEL = "ru.orex.ray/tunnel"
        private const val EVENT_CHANNEL = "ru.orex.ray/tunnel_events"
        private const val VPN_PERMISSION_REQUEST = 7711
    }

    private var pendingConfig: String? = null

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, METHOD_CHANNEL)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "start" -> {
                        val config = call.argument<String>("config")
                        if (config.isNullOrBlank()) {
                            result.error("invalid_config", "Xray config is empty", null)
                            return@setMethodCallHandler
                        }
                        requestVpnAndStart(config)
                        result.success(null)
                    }

                    "stop" -> {
                        stopVpn()
                        result.success(null)
                    }

                    "status" -> result.success(OrexRayTunnelEvents.lastEvent)
                    else -> result.notImplemented()
                }
            }

        EventChannel(flutterEngine.dartExecutor.binaryMessenger, EVENT_CHANNEL)
            .setStreamHandler(object : EventChannel.StreamHandler {
                override fun onListen(arguments: Any?, events: EventChannel.EventSink) {
                    OrexRayTunnelEvents.attach(events)
                }

                override fun onCancel(arguments: Any?) {
                    OrexRayTunnelEvents.detach()
                }
            })
    }

    private fun requestVpnAndStart(config: String) {
        pendingConfig = config
        val permissionIntent = VpnService.prepare(this)
        if (permissionIntent != null) {
            OrexRayTunnelEvents.emit(
                OrexRayTunnelEvents.event(
                    status = "connecting",
                    message = "Подтверди системное разрешение VPN",
                ),
            )
            startActivityForResult(permissionIntent, VPN_PERMISSION_REQUEST)
            return
        }
        pendingConfig = null
        startVpn(config)
    }

    @Deprecated("The platform callback is required for the VPN permission activity")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != VPN_PERMISSION_REQUEST) return

        val config = pendingConfig
        pendingConfig = null
        if (resultCode == Activity.RESULT_OK && !config.isNullOrBlank()) {
            startVpn(config)
        } else {
            OrexRayTunnelEvents.emit(
                OrexRayTunnelEvents.event(
                    status = "error",
                    errorMessage = "Разрешение VPN не выдано",
                ),
            )
        }
    }

    private fun startVpn(config: String) {
        val intent = Intent(this, OrexRayVpnService::class.java)
            .setAction(OrexRayVpnService.ACTION_START)
            .putExtra(OrexRayVpnService.EXTRA_CONFIG, config)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
    }

    private fun stopVpn() {
        // If the Android VPN permission sheet is still open, approving it after
        // a user pressed Stop must not start a stale connection.
        pendingConfig = null
        val intent = Intent(this, OrexRayVpnService::class.java)
            .setAction(OrexRayVpnService.ACTION_STOP)
        startService(intent)
    }
}
