# OrexRay 0.3.0

Flutter-клиент Xray в визуальном языке Orex для Windows и Android.

## Что работает

### Windows

- импорт, хранение и выбор `vless://` профилей;
- VLESS: `none`, TLS, REALITY;
- RAW/TCP, WebSocket, gRPC, XHTTP, HTTPUpgrade;
- автоматическая загрузка и SHA-256 проверка Xray Core;
- `xray run -test -c` перед подключением;
- системный Xray TUN, подключение/отключение и статистика;
- UAC manifest встроен через `Runner.rc`, линкер не использует merge-шаг `mt.exe`.

### Android

- настоящий Android `VpnService`, а не mock;
- системный запрос разрешения VPN;
- foreground service с постоянным уведомлением;
- создание TUN через `VpnService.Builder`;
- передача TUN file descriptor в Xray Core;
- Xray Core через pinned `AndroidLibXrayLite` AAR;
- MethodChannel для start/stop/status;
- EventChannel для статуса и статистики;
- трафик и длительность подключения возвращаются в общий Flutter UI.

Первый Android build скачивает `libv2ray.aar` версии `v26.6.27` (около 56 MB) и проверяет его SHA-256. Файл кладётся в `android/app/libs/` и повторно не скачивается, пока checksum совпадает.

## Windows: запуск

```powershell
flutter clean
flutter pub get
flutter analyze
flutter test
flutter run -d windows
```

## Android: запуск

Подключите устройство с USB debugging или запустите эмулятор:

```powershell
flutter devices
flutter clean
flutter pub get
flutter run -d <ANDROID_DEVICE_ID>
```

При первом нажатии Connect Android покажет системное окно разрешения VPN. После подтверждения OrexRay создаёт TUN и запускает Xray Core с его file descriptor.

## Архитектура

```text
Flutter UI
   |
   +-- ProfilesController
   |      +-- VlessLinkParser
   |      +-- SharedPreferences
   |
   +-- TunnelController
          |
          +-- WindowsXrayEngine
          |      +-- XrayCoreManager
          |      +-- xray.exe + Wintun
          |
          +-- AndroidXrayEngine
                 +-- MethodChannel / EventChannel
                 +-- OrexRayVpnService
                 +-- Android TUN fd
                 +-- AndroidLibXrayLite / Xray Core
```

## Ограничения MVP

- только IPv4 TUN;
- нет per-app split tunneling UI;
- исходная share-ссылка и профиль пока сохраняются в `SharedPreferences`;
- Android core pin обновляется вручную;
- перед публичным релизом нужны secure storage, privacy policy и полноценный экран open-source notices.

См. `MILESTONE_03.md`, `UPDATE_0.3.0.md` и `THIRD_PARTY_NOTICES.md`.
