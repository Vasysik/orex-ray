import 'dart:async';

import 'package:flutter/services.dart';

import '../../core/tunnel/tunnel_engine.dart';
import '../../core/tunnel/tunnel_models.dart';
import '../../core/xray/xray_config_builder.dart';

class AndroidXrayEngine implements TunnelEngine {
  AndroidXrayEngine({XrayConfigBuilder? configBuilder})
      : _configBuilder = configBuilder ?? const XrayConfigBuilder() {
    _eventSubscription = _events.receiveBroadcastStream().listen(
      _onNativeEvent,
      onError: _onNativeStreamError,
    );
    unawaited(_syncNativeStatus());
  }

  static const _channel = MethodChannel('ru.orex.ray/tunnel');
  static const _events = EventChannel('ru.orex.ray/tunnel_events');

  final XrayConfigBuilder _configBuilder;
  final _snapshots = StreamController<TunnelSnapshot>.broadcast();
  late final StreamSubscription<dynamic> _eventSubscription;

  TunnelProfile? _activeProfile;
  TunnelSnapshot _current = const TunnelSnapshot(
    status: TunnelStatus.disconnected,
    stats: TrafficStats(),
  );

  @override
  TunnelSnapshot get current => _current;

  @override
  Stream<TunnelSnapshot> get snapshots => _snapshots.stream;

  @override
  Future<void> start(TunnelProfile profile) async {
    if (_current.isBusy || _current.isConnected) return;

    _activeProfile = profile;
    _emit(
      TunnelSnapshot(
        status: TunnelStatus.connecting,
        profile: profile,
        stats: const TrafficStats(),
        message: 'Готовим Android VPN…',
      ),
    );

    try {
      final config = _configBuilder.buildAndroidTun(profile);
      await _channel.invokeMethod<void>('start', <String, Object?>{
        'config': config,
      });
    } on PlatformException catch (error) {
      _emitError(error.message ?? error.code);
    } catch (error) {
      _emitError(error.toString());
    }
  }

  @override
  Future<void> stop() async {
    if (_current.status == TunnelStatus.disconnected ||
        _current.status == TunnelStatus.disconnecting) {
      return;
    }

    _emit(
      _current.copyWith(
        status: TunnelStatus.disconnecting,
        message: 'Останавливаем Android VPN…',
        clearError: true,
      ),
    );

    try {
      await _channel.invokeMethod<void>('stop');
    } on PlatformException catch (error) {
      _emitError(error.message ?? error.code);
    } catch (error) {
      _emitError(error.toString());
    }
  }

  Future<void> _syncNativeStatus() async {
    try {
      final event = await _channel.invokeMapMethod<String, dynamic>('status');
      if (event != null) _applyEvent(event);
    } catch (_) {
      // The live EventChannel will deliver the first state as soon as the
      // Android side is attached. A failed cold-start sync is non-fatal.
    }
  }

  void _onNativeEvent(dynamic event) {
    if (event is Map) {
      _applyEvent(Map<String, dynamic>.from(event));
    }
  }

  void _applyEvent(Map<String, dynamic> event) {
    final status = switch (event['status']) {
      'connecting' => TunnelStatus.connecting,
      'connected' => TunnelStatus.connected,
      'disconnecting' => TunnelStatus.disconnecting,
      'error' => TunnelStatus.error,
      _ => TunnelStatus.disconnected,
    };

    final downloadBytes = (event['downloadBytes'] as num?)?.toInt() ?? 0;
    final uploadBytes = (event['uploadBytes'] as num?)?.toInt() ?? 0;
    final durationSeconds = (event['durationSeconds'] as num?)?.toInt() ?? 0;

    _emit(
      TunnelSnapshot(
        status: status,
        profile: _activeProfile,
        stats: TrafficStats(
          downloadBytes: downloadBytes,
          uploadBytes: uploadBytes,
          duration: Duration(seconds: durationSeconds),
        ),
        message: event['message'] as String?,
        errorMessage: event['errorMessage'] as String?,
      ),
    );
  }

  void _onNativeStreamError(Object error) => _emitError(error.toString());

  void _emitError(String message) {
    _emit(
      _current.copyWith(
        status: TunnelStatus.error,
        profile: _activeProfile,
        errorMessage: message,
        clearMessage: true,
      ),
    );
  }

  void _emit(TunnelSnapshot value) {
    _current = value;
    if (!_snapshots.isClosed) _snapshots.add(value);
  }

  @override
  Future<void> dispose() async {
    await _eventSubscription.cancel();
    await _snapshots.close();
  }
}
