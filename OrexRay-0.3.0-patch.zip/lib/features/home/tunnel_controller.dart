import 'dart:async';

import 'package:flutter/foundation.dart';

import '../../core/profiles/profiles_controller.dart';
import '../../core/tunnel/tunnel_engine.dart';
import '../../core/tunnel/tunnel_models.dart';

class TunnelController extends ChangeNotifier {
  TunnelController({
    required TunnelEngine engine,
    required ProfilesController profiles,
  })  : _engine = engine,
        _profiles = profiles,
        _engineSnapshot = engine.current {
    _engineSubscription = _engine.snapshots.listen((value) {
      _engineSnapshot = value;
      notifyListeners();
    });
    _profiles.addListener(_onProfilesChanged);
  }

  final TunnelEngine _engine;
  final ProfilesController _profiles;
  late final StreamSubscription<TunnelSnapshot> _engineSubscription;
  TunnelSnapshot _engineSnapshot;

  TunnelSnapshot get snapshot {
    if ((_engineSnapshot.isConnected || _engineSnapshot.isBusy) &&
        _engineSnapshot.profile != null) {
      return _engineSnapshot;
    }
    final selected = _profiles.selectedProfile;
    return _engineSnapshot.copyWith(
      profile: selected,
      clearProfile: selected == null,
    );
  }

  TunnelProfile? get selectedProfile => _profiles.selectedProfile;

  Future<void> toggle() async {
    final current = snapshot;
    if (current.isBusy) return;
    if (current.isConnected) {
      await _engine.stop();
      _engineSnapshot = _engine.current;
      notifyListeners();
      return;
    }

    final profile = _profiles.selectedProfile;
    if (profile == null) {
      notifyListeners();
      return;
    }
    await _engine.start(profile);
    _engineSnapshot = _engine.current;
    notifyListeners();
  }

  void _onProfilesChanged() => notifyListeners();

  @override
  void dispose() {
    _profiles.removeListener(_onProfilesChanged);
    unawaited(_engineSubscription.cancel());
    unawaited(_engine.dispose());
    super.dispose();
  }
}
