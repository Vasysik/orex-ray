import 'package:flutter/material.dart';

import '../../shared/theme/glass.dart';
import '../../shared/theme/orex_theme.dart';
import '../../shared/theme/theme_controller.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key, required this.theme});

  final ThemeController theme;

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        Text('Настройки', style: Theme.of(context).textTheme.headlineSmall),
        const SizedBox(height: 4),
        Text(
          'Поведение, оформление и параметры туннеля',
          style: Theme.of(context).textTheme.bodySmall,
        ),
        const SizedBox(height: 20),
        _Section(
          title: 'Оформление',
          children: [
            RadioGroup<ThemeMode>(
              groupValue: theme.mode,
              onChanged: (mode) {
                if (mode != null) {
                  theme.setMode(mode);
                }
              },
              child: const Column(
                children: [
                  RadioListTile<ThemeMode>(
                    value: ThemeMode.dark,
                    title: Text('Тёмная'),
                  ),
                  RadioListTile<ThemeMode>(
                    value: ThemeMode.light,
                    title: Text('Светлая'),
                  ),
                  RadioListTile<ThemeMode>(
                    value: ThemeMode.system,
                    title: Text('Системная'),
                  ),
                ],
              ),
            ),
          ],
        ),
        const SizedBox(height: 16),
        const _Section(
          title: 'Подключение',
          children: [
            ListTile(
              leading: Icon(Icons.route_rounded, color: OrexColors.copper),
              title: Text('Режим маршрутизации'),
              subtitle: Text('Весь трафик'),
              trailing: Icon(Icons.chevron_right_rounded),
            ),
            Divider(height: 1),
            ListTile(
              leading: Icon(Icons.dns_outlined, color: OrexColors.copper),
              title: Text('DNS'),
              subtitle: Text('Автоматически'),
              trailing: Icon(Icons.chevron_right_rounded),
            ),
            Divider(height: 1),
            SwitchListTile(
              secondary: Icon(Icons.power_rounded, color: OrexColors.copper),
              title: Text('Автоподключение'),
              subtitle: Text('Подключаться после запуска'),
              value: false,
              onChanged: null,
            ),
          ],
        ),
        const SizedBox(height: 16),
        const _Section(
          title: 'О приложении',
          children: [
            ListTile(
              leading: Icon(Icons.pets_rounded, color: OrexColors.copper),
              title: Text('OrexRay'),
              subtitle: Text('Версия 0.3.0 · Windows + Android TUN'),
            ),
          ],
        ),
      ],
    );
  }
}

class _Section extends StatelessWidget {
  const _Section({required this.title, required this.children});

  final String title;
  final List<Widget> children;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 8, bottom: 8),
          child: Text(
            title.toUpperCase(),
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  letterSpacing: 1.1,
                  color: OrexColors.copper,
                  fontWeight: FontWeight.w700,
                ),
          ),
        ),
        GlassPanel(borderRadius: 20, child: Column(children: children)),
      ],
    );
  }
}
